/*
 ============================================================================
 Name        : FreeRTOSHelloWorld.c
 Author      : Mojtaba
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>
#include <stdlib.h>

int main(void) {

	for (;;)
		;
	return 0;
}
